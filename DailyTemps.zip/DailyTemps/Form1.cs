﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DailyTemps
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            // Hide Results until finished.
            DailyTempList.Visible = false;
        }

        // Initialize outside of button click for global scope.
        int DayCount = 1;
        int TempTotal = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            int Temperature = Convert.ToInt32(TempInput.Text);
            // Validate Temperature
            if (Temperature >= -20 && Temperature <= 130) 
            {
                TempError.Text = "";
                // Loop for 7 Days
                if (DayCount < 7)
                {
                    // Accumilating Text and Totals for current pass.
                    DailyTempList.Text += $"Day {DayCount.ToString()} Temperature: {Temperature.ToString()}\n";
                    TempTotal += Temperature;
                    DayCount++;
                    // Set Input Prompts and Feild for Next Pass.
                    TempInputLbl.Text = $"Enter Day {(DayCount).ToString()} Temperature:";
                    TempInput.Text = "";
                    TempInput.Focus();
                }
                else
                {
                    // Pass 7 finalizes Accumilation.
                    DailyTempList.Text += $"Day {DayCount.ToString()} Temperature: {Temperature.ToString()}\n";
                    TempTotal += Temperature;

                    // Display and Exit.
                    AddTempBtn.Enabled = false;
                    AvgTemp.Text = $"Average Daily Temperature: {(TempTotal/7).ToString()}";
                    DailyTempList.Visible=true;
                }
            } else
            {
                TempError.Text = "Invalid Temperature";
            }

        }
    }
}
