﻿namespace DailyTemps
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.TempInputLbl = new System.Windows.Forms.Label();
            this.TempInput = new System.Windows.Forms.TextBox();
            this.AddTempBtn = new System.Windows.Forms.Button();
            this.TempError = new System.Windows.Forms.Label();
            this.DailyTempList = new System.Windows.Forms.Label();
            this.AvgTemp = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(300, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(206, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "DailyTemperature";
            // 
            // TempInputLbl
            // 
            this.TempInputLbl.AutoSize = true;
            this.TempInputLbl.Location = new System.Drawing.Point(160, 130);
            this.TempInputLbl.Name = "TempInputLbl";
            this.TempInputLbl.Size = new System.Drawing.Size(160, 16);
            this.TempInputLbl.TabIndex = 1;
            this.TempInputLbl.Text = "Enter Day 1 Temperature:";
            // 
            // TempInput
            // 
            this.TempInput.Location = new System.Drawing.Point(338, 124);
            this.TempInput.Name = "TempInput";
            this.TempInput.Size = new System.Drawing.Size(100, 22);
            this.TempInput.TabIndex = 2;
            // 
            // AddTempBtn
            // 
            this.AddTempBtn.Location = new System.Drawing.Point(469, 124);
            this.AddTempBtn.Name = "AddTempBtn";
            this.AddTempBtn.Size = new System.Drawing.Size(140, 28);
            this.AddTempBtn.TabIndex = 3;
            this.AddTempBtn.Text = "Add Temperature";
            this.AddTempBtn.UseVisualStyleBackColor = true;
            this.AddTempBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // TempError
            // 
            this.TempError.AutoSize = true;
            this.TempError.ForeColor = System.Drawing.Color.Red;
            this.TempError.Location = new System.Drawing.Point(335, 159);
            this.TempError.Name = "TempError";
            this.TempError.Size = new System.Drawing.Size(0, 16);
            this.TempError.TabIndex = 4;
            // 
            // DailyTempList
            // 
            this.DailyTempList.Location = new System.Drawing.Point(257, 211);
            this.DailyTempList.Name = "DailyTempList";
            this.DailyTempList.Size = new System.Drawing.Size(249, 191);
            this.DailyTempList.TabIndex = 5;
            // 
            // AvgTemp
            // 
            this.AvgTemp.AutoSize = true;
            this.AvgTemp.Location = new System.Drawing.Point(512, 211);
            this.AvgTemp.Name = "AvgTemp";
            this.AvgTemp.Size = new System.Drawing.Size(0, 16);
            this.AvgTemp.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AvgTemp);
            this.Controls.Add(this.DailyTempList);
            this.Controls.Add(this.TempError);
            this.Controls.Add(this.AddTempBtn);
            this.Controls.Add(this.TempInput);
            this.Controls.Add(this.TempInputLbl);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label TempInputLbl;
        private System.Windows.Forms.TextBox TempInput;
        private System.Windows.Forms.Button AddTempBtn;
        private System.Windows.Forms.Label TempError;
        private System.Windows.Forms.Label DailyTempList;
        private System.Windows.Forms.Label AvgTemp;
    }
}

